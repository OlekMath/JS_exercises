function onHover(i) {
    let image = document.getElementsByTagName('img')[i];
    const originalSrc = image.src;
    //console.log(image);
    const grayscaleSrc = originalSrc.replace('.jpg', '-szary.jpg');
    image.src = grayscaleSrc;
}

function onLeave(i) {
    let image = document.getElementsByTagName('img')[i];
    const grayscaleSrc = image.src;
    const originalSrc = grayscaleSrc.replace('-szary.jpg', '.jpg');
    image.src = originalSrc;
}

function onClick(i) {
    let image = document.getElementsByTagName('img')[i];
    const grayscaleSrc = image.src;
    const originalSrc = grayscaleSrc.replace('-szary.jpg', '.jpg');
    image.src = originalSrc;
  
    const displayImg = document.getElementById('displayImg');
    displayImg.src = originalSrc;
}

